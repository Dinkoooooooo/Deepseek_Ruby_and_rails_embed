require 'ruby/openai'
require 'dotenv/load'

client = OpenAI::Client.new(access_token: ENV['OPENAI_API_KEY'])

response = client.completions(
  parameters: {
    model: "gpt-3.5-turbo",
    prompt: "Hello, world!",
    max_tokens: 50
  }
)

puts response
