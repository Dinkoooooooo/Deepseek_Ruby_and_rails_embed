class CreateChatGptJobResponses < ActiveRecord::Migration[7.2]
  def change
    create_table :chat_gpt_job_responses do |t|
      t.string :job_id
      t.string :state
      t.text :data
      t.text :error

      t.timestamps
    end
  end
end
