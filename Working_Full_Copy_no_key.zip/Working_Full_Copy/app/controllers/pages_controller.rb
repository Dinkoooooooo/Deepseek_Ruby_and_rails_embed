class PagesController < ApplicationController
  def blank
  end
end
